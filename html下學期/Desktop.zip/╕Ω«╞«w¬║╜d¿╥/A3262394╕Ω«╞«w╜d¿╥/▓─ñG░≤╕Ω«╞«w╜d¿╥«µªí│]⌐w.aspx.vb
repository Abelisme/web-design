﻿
Partial Class 第二堂資料庫範例格式設定
    Inherits System.Web.UI.Page

End Class
